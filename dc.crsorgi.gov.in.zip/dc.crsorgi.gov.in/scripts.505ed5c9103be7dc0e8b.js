! function(t, e) {
    "object" == typeof exports && "undefined" != typeof module ? module.exports = e(require("@popperjs/core")) : "function" == typeof define && define.amd ? define(["@popperjs/core"], e) : (t = "undefined" != typeof globalThis ? globalThis : t || self).bootstrap = e(t.Popper)
}(this, function(t) {
    "use strict";
    const e = function(t) {
            if (t && t.__esModule) return t;
            const e = Object.create(null);
            if (t)
                for (const i in t)
                    if ("default" !== i) {
                        const s = Object.getOwnPropertyDescriptor(t, i);
                        Object.defineProperty(e, i, s.get ? s : {
                            enumerable: !0,
                            get: () => t[i]
                        })
                    }
            return e.default = t, Object.freeze(e)
        }(t),
        i = "transitionend",
        s = t => {
            let e = t.getAttribute("data-bs-target");
            if (!e || "#" === e) {
                let i = t.getAttribute("href");
                if (!i || !i.includes("#") && !i.startsWith(".")) return null;
                i.includes("#") && !i.startsWith("#") && (i = `#${i.split("#")[1]}`), e = i && "#" !== i ? i.trim() : null
            }
            return e
        },
        n = t => {
            const e = s(t);
            return e && document.querySelector(e) ? e : null
        },
        o = t => {
            const e = s(t);
            return e ? document.querySelector(e) : null
        },
        r = t => {
            t.dispatchEvent(new Event(i))
        },
        a = t => !(!t || "object" != typeof t) && (void 0 !== t.jquery && (t = t[0]), void 0 !== t.nodeType),
        l = t => a(t) ? t.jquery ? t[0] : t : "string" == typeof t && t.length > 0 ? document.querySelector(t) : null,
        c = (t, e, i) => {
            Object.keys(i).forEach(s => {
                const n = i[s],
                    o = e[s],
                    r = o && a(o) ? "element" : null == (l = o) ? `${l}` : {}.toString.call(l).match(/\s([a-z]+)/i)[1].toLowerCase();
                var l;
                if (!new RegExp(n).test(r)) throw new TypeError(`${t.toUpperCase()}: Option "${s}" provided type "${r}" but expected type "${n}".`)
            })
        },
        h = t => !(!a(t) || 0 === t.getClientRects().length) && "visible" === getComputedStyle(t).getPropertyValue("visibility"),
        d = t => !t || t.nodeType !== Node.ELEMENT_NODE || !!t.classList.contains("disabled") || (void 0 !== t.disabled ? t.disabled : t.hasAttribute("disabled") && "false" !== t.getAttribute("disabled")),
        u = t => {
            if (!document.documentElement.attachShadow) return null;
            if ("function" == typeof t.getRootNode) {
                const e = t.getRootNode();
                return e instanceof ShadowRoot ? e : null
            }
            return t instanceof ShadowRoot ? t : t.parentNode ? u(t.parentNode) : null
        },
        g = () => {},
        _ = () => {
            const {
                jQuery: t
            } = window;
            return t && !document.body.hasAttribute("data-bs-no-jquery") ? t : null
        },
        p = [],
        f = () => "rtl" === document.documentElement.dir,
        m = t => {
            var e;
            e = () => {
                const e = _();
                if (e) {
                    const i = t.NAME,
                        s = e.fn[i];
                    e.fn[i] = t.jQueryInterface, e.fn[i].Constructor = t, e.fn[i].noConflict = () => (e.fn[i] = s, t.jQueryInterface)
                }
            }, "loading" === document.readyState ? (p.length || document.addEventListener("DOMContentLoaded", () => {
                p.forEach(t => t())
            }), p.push(e)) : e()
        },
        b = t => {
            "function" == typeof t && t()
        },
        v = (t, e, s = !0) => {
            if (!s) return void b(t);
            const n = (t => {
                if (!t) return 0;
                let {
                    transitionDuration: e,
                    transitionDelay: i
                } = window.getComputedStyle(t);
                const s = Number.parseFloat(e),
                    n = Number.parseFloat(i);
                return s || n ? (e = e.split(",")[0], i = i.split(",")[0], 1e3 * (Number.parseFloat(e) + Number.parseFloat(i))) : 0
            })(e) + 5;
            let o = !1;
            const a = ({
                target: s
            }) => {
                s === e && (o = !0, e.removeEventListener(i, a), b(t))
            };
            e.addEventListener(i, a), setTimeout(() => {
                o || r(e)
            }, n)
        },
        y = (t, e, i, s) => {
            let n = t.indexOf(e);
            if (-1 === n) return t[!i && s ? t.length - 1 : 0];
            const o = t.length;
            return n += i ? 1 : -1, s && (n = (n + o) % o), t[Math.max(0, Math.min(n, o - 1))]
        },
        E = /[^.]*(?=\..*)\.|.*/,
        w = /\..*/,
        A = /::\d+$/,
        T = {};
    let C = 1;
    const k = {
            mouseenter: "mouseover",
            mouseleave: "mouseout"
        },
        L = /^(mouseenter|mouseleave)/i,
        S = new Set(["click", "dblclick", "mouseup", "mousedown", "contextmenu", "mousewheel", "DOMMouseScroll", "mouseover", "mouseout", "mousemove", "selectstart", "selectend", "keydown", "keypress", "keyup", "orientationchange", "touchstart", "touchmove", "touchend", "touchcancel", "pointerdown", "pointermove", "pointerup", "pointerleave", "pointercancel", "gesturestart", "gesturechange", "gestureend", "focus", "blur", "change", "reset", "select", "submit", "focusin", "focusout", "load", "unload", "beforeunload", "resize", "move", "DOMContentLoaded", "readystatechange", "error", "abort", "scroll"]);

    function O(t, e) {
        return e && `${e}::${C++}` || t.uidEvent || C++
    }

    function N(t) {
        const e = O(t);
        return t.uidEvent = e, T[e] = T[e] || {}, T[e]
    }

    function D(t, e, i = null) {
        const s = Object.keys(t);
        for (let n = 0, o = s.length; n < o; n++) {
            const o = t[s[n]];
            if (o.originalHandler === e && o.delegationSelector === i) return o
        }
        return null
    }

    function I(t, e, i) {
        const s = "string" == typeof e,
            n = s ? i : e;
        let o = M(t);
        return S.has(o) || (o = t), [s, n, o]
    }

    function P(t, e, i, s, n) {
        if ("string" != typeof e || !t) return;
        if (i || (i = s, s = null), L.test(e)) {
            const t = t => function(e) {
                if (!e.relatedTarget || e.relatedTarget !== e.delegateTarget && !e.delegateTarget.contains(e.relatedTarget)) return t.call(this, e)
            };
            s ? s = t(s) : i = t(i)
        }
        const [o, r, a] = I(e, i, s), l = N(t), c = l[a] || (l[a] = {}), h = D(c, r, o ? i : null);
        if (h) return void(h.oneOff = h.oneOff && n);
        const d = O(r, e.replace(E, "")),
            u = o ? function(t, e, i) {
                return function s(n) {
                    const o = t.querySelectorAll(e);
                    for (let {
                            target: r
                        } = n; r && r !== this; r = r.parentNode)
                        for (let a = o.length; a--;)
                            if (o[a] === r) return n.delegateTarget = r, s.oneOff && j.off(t, n.type, e, i), i.apply(r, [n]);
                    return null
                }
            }(t, i, s) : function(t, e) {
                return function i(s) {
                    return s.delegateTarget = t, i.oneOff && j.off(t, s.type, e), e.apply(t, [s])
                }
            }(t, i);
        u.delegationSelector = o ? i : null, u.originalHandler = r, u.oneOff = n, u.uidEvent = d, c[d] = u, t.addEventListener(a, u, o)
    }

    function x(t, e, i, s, n) {
        const o = D(e[i], s, n);
        o && (t.removeEventListener(i, o, Boolean(n)), delete e[i][o.uidEvent])
    }

    function M(t) {
        return t = t.replace(w, ""), k[t] || t
    }
    const j = {
            on(t, e, i, s) {
                P(t, e, i, s, !1)
            },
            one(t, e, i, s) {
                P(t, e, i, s, !0)
            },
            off(t, e, i, s) {
                if ("string" != typeof e || !t) return;
                const [n, o, r] = I(e, i, s), a = r !== e, l = N(t), c = e.startsWith(".");
                if (void 0 !== o) {
                    if (!l || !l[r]) return;
                    return void x(t, l, r, o, n ? i : null)
                }
                c && Object.keys(l).forEach(i => {
                    ! function(t, e, i, s) {
                        const n = e[i] || {};
                        Object.keys(n).forEach(o => {
                            if (o.includes(s)) {
                                const s = n[o];
                                x(t, e, i, s.originalHandler, s.delegationSelector)
                            }
                        })
                    }(t, l, i, e.slice(1))
                });
                const h = l[r] || {};
                Object.keys(h).forEach(i => {
                    const s = i.replace(A, "");
                    if (!a || e.includes(s)) {
                        const e = h[i];
                        x(t, l, r, e.originalHandler, e.delegationSelector)
                    }
                })
            },
            trigger(t, e, i) {
                if ("string" != typeof e || !t) return null;
                const s = _(),
                    n = M(e),
                    o = e !== n,
                    r = S.has(n);
                let a, l = !0,
                    c = !0,
                    h = !1,
                    d = null;
                return o && s && (a = s.Event(e, i), s(t).trigger(a), l = !a.isPropagationStopped(), c = !a.isImmediatePropagationStopped(), h = a.isDefaultPrevented()), r ? (d = document.createEvent("HTMLEvents"), d.initEvent(n, l, !0)) : d = new CustomEvent(e, {
                    bubbles: l,
                    cancelable: !0
                }), void 0 !== i && Object.keys(i).forEach(t => {
                    Object.defineProperty(d, t, {
                        get: () => i[t]
                    })
                }), h && d.preventDefault(), c && t.dispatchEvent(d), d.defaultPrevented && void 0 !== a && a.preventDefault(), d
            }
        },
        H = new Map,
        $ = {
            set(t, e, i) {
                H.has(t) || H.set(t, new Map);
                const s = H.get(t);
                s.has(e) || 0 === s.size ? s.set(e, i) : console.error(`Bootstrap doesn't allow more than one instance per element. Bound instance: ${Array.from(s.keys())[0]}.`)
            },
            get: (t, e) => H.has(t) && H.get(t).get(e) || null,
            remove(t, e) {
                if (!H.has(t)) return;
                const i = H.get(t);
                i.delete(e), 0 === i.size && H.delete(t)
            }
        };
    class B {
        constructor(t) {
            (t = l(t)) && (this._element = t, $.set(this._element, this.constructor.DATA_KEY, this))
        }
        dispose() {
            $.remove(this._element, this.constructor.DATA_KEY), j.off(this._element, this.constructor.EVENT_KEY), Object.getOwnPropertyNames(this).forEach(t => {
                this[t] = null
            })
        }
        _queueCallback(t, e, i = !0) {
            v(t, e, i)
        }
        static getInstance(t) {
            return $.get(l(t), this.DATA_KEY)
        }
        static getOrCreateInstance(t, e = {}) {
            return this.getInstance(t) || new this(t, "object" == typeof e ? e : null)
        }
        static get VERSION() {
            return "5.1.3"
        }
        static get NAME() {
            throw new Error('You have to implement the static method "NAME", for each component!')
        }
        static get DATA_KEY() {
            return `bs.${this.NAME}`
        }
        static get EVENT_KEY() {
            return `.${this.DATA_KEY}`
        }
    }
    const z = (t, e = "hide") => {
        const i = t.NAME;
        j.on(document, `click.dismiss${t.EVENT_KEY}`, `[data-bs-dismiss="${i}"]`, function(s) {
            if (["A", "AREA"].includes(this.tagName) && s.preventDefault(), d(this)) return;
            const n = o(this) || this.closest(`.${i}`);
            t.getOrCreateInstance(n)[e]()
        })
    };
    class R extends B {
        static get NAME() {
            return "alert"
        }
        close() {
            if (j.trigger(this._element, "close.bs.alert").defaultPrevented) return;
            this._element.classList.remove("show");
            const t = this._element.classList.contains("fade");
            this._queueCallback(() => this._destroyElement(), this._element, t)
        }
        _destroyElement() {
            this._element.remove(), j.trigger(this._element, "closed.bs.alert"), this.dispose()
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const e = R.getOrCreateInstance(this);
                if ("string" == typeof t) {
                    if (void 0 === e[t] || t.startsWith("_") || "constructor" === t) throw new TypeError(`No method named "${t}"`);
                    e[t](this)
                }
            })
        }
    }
    z(R, "close"), m(R);
    const F = '[data-bs-toggle="button"]';
    class q extends B {
        static get NAME() {
            return "button"
        }
        toggle() {
            this._element.setAttribute("aria-pressed", this._element.classList.toggle("active"))
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const e = q.getOrCreateInstance(this);
                "toggle" === t && e[t]()
            })
        }
    }

    function W(t) {
        return "true" === t || "false" !== t && (t === Number(t).toString() ? Number(t) : "" === t || "null" === t ? null : t)
    }

    function U(t) {
        return t.replace(/[A-Z]/g, t => `-${t.toLowerCase()}`)
    }
    j.on(document, "click.bs.button.data-api", F, t => {
        t.preventDefault();
        const e = t.target.closest(F);
        q.getOrCreateInstance(e).toggle()
    }), m(q);
    const K = {
            setDataAttribute(t, e, i) {
                t.setAttribute(`data-bs-${U(e)}`, i)
            },
            removeDataAttribute(t, e) {
                t.removeAttribute(`data-bs-${U(e)}`)
            },
            getDataAttributes(t) {
                if (!t) return {};
                const e = {};
                return Object.keys(t.dataset).filter(t => t.startsWith("bs")).forEach(i => {
                    let s = i.replace(/^bs/, "");
                    s = s.charAt(0).toLowerCase() + s.slice(1, s.length), e[s] = W(t.dataset[i])
                }), e
            },
            getDataAttribute: (t, e) => W(t.getAttribute(`data-bs-${U(e)}`)),
            offset(t) {
                const e = t.getBoundingClientRect();
                return {
                    top: e.top + window.pageYOffset,
                    left: e.left + window.pageXOffset
                }
            },
            position: t => ({
                top: t.offsetTop,
                left: t.offsetLeft
            })
        },
        V = {
            find: (t, e = document.documentElement) => [].concat(...Element.prototype.querySelectorAll.call(e, t)),
            findOne: (t, e = document.documentElement) => Element.prototype.querySelector.call(e, t),
            children: (t, e) => [].concat(...t.children).filter(t => t.matches(e)),
            parents(t, e) {
                const i = [];
                let s = t.parentNode;
                for (; s && s.nodeType === Node.ELEMENT_NODE && 3 !== s.nodeType;) s.matches(e) && i.push(s), s = s.parentNode;
                return i
            },
            prev(t, e) {
                let i = t.previousElementSibling;
                for (; i;) {
                    if (i.matches(e)) return [i];
                    i = i.previousElementSibling
                }
                return []
            },
            next(t, e) {
                let i = t.nextElementSibling;
                for (; i;) {
                    if (i.matches(e)) return [i];
                    i = i.nextElementSibling
                }
                return []
            },
            focusableChildren(t) {
                const e = ["a", "button", "input", "textarea", "select", "details", "[tabindex]", '[contenteditable="true"]'].map(t => `${t}:not([tabindex^="-"])`).join(", ");
                return this.find(e, t).filter(t => !d(t) && h(t))
            }
        },
        X = "carousel",
        Y = {
            interval: 5e3,
            keyboard: !0,
            slide: !1,
            pause: "hover",
            wrap: !0,
            touch: !0
        },
        Q = {
            interval: "(number|boolean)",
            keyboard: "boolean",
            slide: "(boolean|string)",
            pause: "(string|boolean)",
            wrap: "boolean",
            touch: "boolean"
        },
        G = "next",
        Z = "prev",
        J = "left",
        tt = "right",
        et = {
            ArrowLeft: tt,
            ArrowRight: J
        },
        it = "slid.bs.carousel",
        st = "active",
        nt = ".active.carousel-item";
    class ot extends B {
        constructor(t, e) {
            super(t), this._items = null, this._interval = null, this._activeElement = null, this._isPaused = !1, this._isSliding = !1, this.touchTimeout = null, this.touchStartX = 0, this.touchDeltaX = 0, this._config = this._getConfig(e), this._indicatorsElement = V.findOne(".carousel-indicators", this._element), this._touchSupported = "ontouchstart" in document.documentElement || navigator.maxTouchPoints > 0, this._pointerEvent = Boolean(window.PointerEvent), this._addEventListeners()
        }
        static get Default() {
            return Y
        }
        static get NAME() {
            return X
        }
        next() {
            this._slide(G)
        }
        nextWhenVisible() {
            !document.hidden && h(this._element) && this.next()
        }
        prev() {
            this._slide(Z)
        }
        pause(t) {
            t || (this._isPaused = !0), V.findOne(".carousel-item-next, .carousel-item-prev", this._element) && (r(this._element), this.cycle(!0)), clearInterval(this._interval), this._interval = null
        }
        cycle(t) {
            t || (this._isPaused = !1), this._interval && (clearInterval(this._interval), this._interval = null), this._config && this._config.interval && !this._isPaused && (this._updateInterval(), this._interval = setInterval((document.visibilityState ? this.nextWhenVisible : this.next).bind(this), this._config.interval))
        }
        to(t) {
            this._activeElement = V.findOne(nt, this._element);
            const e = this._getItemIndex(this._activeElement);
            if (!(t > this._items.length - 1 || t < 0)) {
                if (!this._isSliding) return e === t ? (this.pause(), void this.cycle()) : void this._slide(t > e ? G : Z, this._items[t]);
                j.one(this._element, it, () => this.to(t))
            }
        }
        _getConfig(t) {
            return t = { ...Y,
                ...K.getDataAttributes(this._element),
                ..."object" == typeof t ? t : {}
            }, c(X, t, Q), t
        }
        _handleSwipe() {
            const t = Math.abs(this.touchDeltaX);
            if (t <= 40) return;
            const e = t / this.touchDeltaX;
            this.touchDeltaX = 0, e && this._slide(e > 0 ? tt : J)
        }
        _addEventListeners() {
            this._config.keyboard && j.on(this._element, "keydown.bs.carousel", t => this._keydown(t)), "hover" === this._config.pause && (j.on(this._element, "mouseenter.bs.carousel", t => this.pause(t)), j.on(this._element, "mouseleave.bs.carousel", t => this.cycle(t))), this._config.touch && this._touchSupported && this._addTouchEventListeners()
        }
        _addTouchEventListeners() {
            const t = t => this._pointerEvent && ("pen" === t.pointerType || "touch" === t.pointerType),
                e = e => {
                    t(e) ? this.touchStartX = e.clientX : this._pointerEvent || (this.touchStartX = e.touches[0].clientX)
                },
                i = t => {
                    this.touchDeltaX = t.touches && t.touches.length > 1 ? 0 : t.touches[0].clientX - this.touchStartX
                },
                s = e => {
                    t(e) && (this.touchDeltaX = e.clientX - this.touchStartX), this._handleSwipe(), "hover" === this._config.pause && (this.pause(), this.touchTimeout && clearTimeout(this.touchTimeout), this.touchTimeout = setTimeout(t => this.cycle(t), 500 + this._config.interval))
                };
            V.find(".carousel-item img", this._element).forEach(t => {
                j.on(t, "dragstart.bs.carousel", t => t.preventDefault())
            }), this._pointerEvent ? (j.on(this._element, "pointerdown.bs.carousel", t => e(t)), j.on(this._element, "pointerup.bs.carousel", t => s(t)), this._element.classList.add("pointer-event")) : (j.on(this._element, "touchstart.bs.carousel", t => e(t)), j.on(this._element, "touchmove.bs.carousel", t => i(t)), j.on(this._element, "touchend.bs.carousel", t => s(t)))
        }
        _keydown(t) {
            if (/input|textarea/i.test(t.target.tagName)) return;
            const e = et[t.key];
            e && (t.preventDefault(), this._slide(e))
        }
        _getItemIndex(t) {
            return this._items = t && t.parentNode ? V.find(".carousel-item", t.parentNode) : [], this._items.indexOf(t)
        }
        _getItemByOrder(t, e) {
            return y(this._items, e, t === G, this._config.wrap)
        }
        _triggerSlideEvent(t, e) {
            const i = this._getItemIndex(t),
                s = this._getItemIndex(V.findOne(nt, this._element));
            return j.trigger(this._element, "slide.bs.carousel", {
                relatedTarget: t,
                direction: e,
                from: s,
                to: i
            })
        }
        _setActiveIndicatorElement(t) {
            if (this._indicatorsElement) {
                const e = V.findOne(".active", this._indicatorsElement);
                e.classList.remove(st), e.removeAttribute("aria-current");
                const i = V.find("[data-bs-target]", this._indicatorsElement);
                for (let s = 0; s < i.length; s++)
                    if (Number.parseInt(i[s].getAttribute("data-bs-slide-to"), 10) === this._getItemIndex(t)) {
                        i[s].classList.add(st), i[s].setAttribute("aria-current", "true");
                        break
                    }
            }
        }
        _updateInterval() {
            const t = this._activeElement || V.findOne(nt, this._element);
            if (!t) return;
            const e = Number.parseInt(t.getAttribute("data-bs-interval"), 10);
            e ? (this._config.defaultInterval = this._config.defaultInterval || this._config.interval, this._config.interval = e) : this._config.interval = this._config.defaultInterval || this._config.interval
        }
        _slide(t, e) {
            const i = this._directionToOrder(t),
                s = V.findOne(nt, this._element),
                n = this._getItemIndex(s),
                o = e || this._getItemByOrder(i, s),
                r = this._getItemIndex(o),
                a = Boolean(this._interval),
                l = i === G,
                c = l ? "carousel-item-start" : "carousel-item-end",
                h = l ? "carousel-item-next" : "carousel-item-prev",
                d = this._orderToDirection(i);
            if (o && o.classList.contains(st)) return void(this._isSliding = !1);
            if (this._isSliding) return;
            if (this._triggerSlideEvent(o, d).defaultPrevented) return;
            if (!s || !o) return;
            this._isSliding = !0, a && this.pause(), this._setActiveIndicatorElement(o), this._activeElement = o;
            const u = () => {
                j.trigger(this._element, it, {
                    relatedTarget: o,
                    direction: d,
                    from: n,
                    to: r
                })
            };
            this._element.classList.contains("slide") ? (o.classList.add(h), s.classList.add(c), o.classList.add(c), this._queueCallback(() => {
                o.classList.remove(c, h), o.classList.add(st), s.classList.remove(st, h, c), this._isSliding = !1, setTimeout(u, 0)
            }, s, !0)) : (s.classList.remove(st), o.classList.add(st), this._isSliding = !1, u()), a && this.cycle()
        }
        _directionToOrder(t) {
            return [tt, J].includes(t) ? f() ? t === J ? Z : G : t === J ? G : Z : t
        }
        _orderToDirection(t) {
            return [G, Z].includes(t) ? f() ? t === Z ? J : tt : t === Z ? tt : J : t
        }
        static carouselInterface(t, e) {
            const i = ot.getOrCreateInstance(t, e);
            let {
                _config: s
            } = i;
            "object" == typeof e && (s = { ...s,
                ...e
            });
            const n = "string" == typeof e ? e : s.slide;
            if ("number" == typeof e) i.to(e);
            else if ("string" == typeof n) {
                if (void 0 === i[n]) throw new TypeError(`No method named "${n}"`);
                i[n]()
            } else s.interval && s.ride && (i.pause(), i.cycle())
        }
        static jQueryInterface(t) {
            return this.each(function() {
                ot.carouselInterface(this, t)
            })
        }
        static dataApiClickHandler(t) {
            const e = o(this);
            if (!e || !e.classList.contains("carousel")) return;
            const i = { ...K.getDataAttributes(e),
                    ...K.getDataAttributes(this)
                },
                s = this.getAttribute("data-bs-slide-to");
            s && (i.interval = !1), ot.carouselInterface(e, i), s && ot.getInstance(e).to(s), t.preventDefault()
        }
    }
    j.on(document, "click.bs.carousel.data-api", "[data-bs-slide], [data-bs-slide-to]", ot.dataApiClickHandler), j.on(window, "load.bs.carousel.data-api", () => {
        const t = V.find('[data-bs-ride="carousel"]');
        for (let e = 0, i = t.length; e < i; e++) ot.carouselInterface(t[e], ot.getInstance(t[e]))
    }), m(ot);
    const rt = "collapse",
        at = {
            toggle: !0,
            parent: null
        },
        lt = {
            toggle: "boolean",
            parent: "(null|element)"
        },
        ct = "show",
        ht = "collapse",
        dt = "collapsing",
        ut = "collapsed",
        gt = ":scope .collapse .collapse",
        _t = '[data-bs-toggle="collapse"]';
    class pt extends B {
        constructor(t, e) {
            super(t), this._isTransitioning = !1, this._config = this._getConfig(e), this._triggerArray = [];
            const i = V.find(_t);
            for (let s = 0, o = i.length; s < o; s++) {
                const t = i[s],
                    e = n(t),
                    o = V.find(e).filter(t => t === this._element);
                null !== e && o.length && (this._selector = e, this._triggerArray.push(t))
            }
            this._initializeChildren(), this._config.parent || this._addAriaAndCollapsedClass(this._triggerArray, this._isShown()), this._config.toggle && this.toggle()
        }
        static get Default() {
            return at
        }
        static get NAME() {
            return rt
        }
        toggle() {
            this._isShown() ? this.hide() : this.show()
        }
        show() {
            if (this._isTransitioning || this._isShown()) return;
            let t, e = [];
            if (this._config.parent) {
                const t = V.find(gt, this._config.parent);
                e = V.find(".collapse.show, .collapse.collapsing", this._config.parent).filter(e => !t.includes(e))
            }
            const i = V.findOne(this._selector);
            if (e.length) {
                const s = e.find(t => i !== t);
                if (t = s ? pt.getInstance(s) : null, t && t._isTransitioning) return
            }
            if (j.trigger(this._element, "show.bs.collapse").defaultPrevented) return;
            e.forEach(e => {
                i !== e && pt.getOrCreateInstance(e, {
                    toggle: !1
                }).hide(), t || $.set(e, "bs.collapse", null)
            });
            const s = this._getDimension();
            this._element.classList.remove(ht), this._element.classList.add(dt), this._element.style[s] = 0, this._addAriaAndCollapsedClass(this._triggerArray, !0), this._isTransitioning = !0;
            const n = `scroll${s[0].toUpperCase()+s.slice(1)}`;
            this._queueCallback(() => {
                this._isTransitioning = !1, this._element.classList.remove(dt), this._element.classList.add(ht, ct), this._element.style[s] = "", j.trigger(this._element, "shown.bs.collapse")
            }, this._element, !0), this._element.style[s] = `${this._element[n]}px`
        }
        hide() {
            if (this._isTransitioning || !this._isShown()) return;
            if (j.trigger(this._element, "hide.bs.collapse").defaultPrevented) return;
            const t = this._getDimension();
            this._element.style[t] = `${this._element.getBoundingClientRect()[t]}px`, this._element.classList.add(dt), this._element.classList.remove(ht, ct);
            const e = this._triggerArray.length;
            for (let i = 0; i < e; i++) {
                const t = this._triggerArray[i],
                    e = o(t);
                e && !this._isShown(e) && this._addAriaAndCollapsedClass([t], !1)
            }
            this._isTransitioning = !0, this._element.style[t] = "", this._queueCallback(() => {
                this._isTransitioning = !1, this._element.classList.remove(dt), this._element.classList.add(ht), j.trigger(this._element, "hidden.bs.collapse")
            }, this._element, !0)
        }
        _isShown(t = this._element) {
            return t.classList.contains(ct)
        }
        _getConfig(t) {
            return (t = { ...at,
                ...K.getDataAttributes(this._element),
                ...t
            }).toggle = Boolean(t.toggle), t.parent = l(t.parent), c(rt, t, lt), t
        }
        _getDimension() {
            return this._element.classList.contains("collapse-horizontal") ? "width" : "height"
        }
        _initializeChildren() {
            if (!this._config.parent) return;
            const t = V.find(gt, this._config.parent);
            V.find(_t, this._config.parent).filter(e => !t.includes(e)).forEach(t => {
                const e = o(t);
                e && this._addAriaAndCollapsedClass([t], this._isShown(e))
            })
        }
        _addAriaAndCollapsedClass(t, e) {
            t.length && t.forEach(t => {
                e ? t.classList.remove(ut) : t.classList.add(ut), t.setAttribute("aria-expanded", e)
            })
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const e = {};
                "string" == typeof t && /show|hide/.test(t) && (e.toggle = !1);
                const i = pt.getOrCreateInstance(this, e);
                if ("string" == typeof t) {
                    if (void 0 === i[t]) throw new TypeError(`No method named "${t}"`);
                    i[t]()
                }
            })
        }
    }
    j.on(document, "click.bs.collapse.data-api", _t, function(t) {
        ("A" === t.target.tagName || t.delegateTarget && "A" === t.delegateTarget.tagName) && t.preventDefault();
        const e = n(this);
        V.find(e).forEach(t => {
            pt.getOrCreateInstance(t, {
                toggle: !1
            }).toggle()
        })
    }), m(pt);
    const ft = "dropdown",
        mt = "Escape",
        bt = "Space",
        vt = "ArrowUp",
        yt = "ArrowDown",
        Et = new RegExp("ArrowUp|ArrowDown|Escape"),
        wt = "click.bs.dropdown.data-api",
        At = "keydown.bs.dropdown.data-api",
        Tt = "show",
        Ct = '[data-bs-toggle="dropdown"]',
        kt = ".dropdown-menu",
        Lt = f() ? "top-end" : "top-start",
        St = f() ? "top-start" : "top-end",
        Ot = f() ? "bottom-end" : "bottom-start",
        Nt = f() ? "bottom-start" : "bottom-end",
        Dt = f() ? "left-start" : "right-start",
        It = f() ? "right-start" : "left-start",
        Pt = {
            offset: [0, 2],
            boundary: "clippingParents",
            reference: "toggle",
            display: "dynamic",
            popperConfig: null,
            autoClose: !0
        },
        xt = {
            offset: "(array|string|function)",
            boundary: "(string|element)",
            reference: "(string|element|object)",
            display: "string",
            popperConfig: "(null|object|function)",
            autoClose: "(boolean|string)"
        };
    class Mt extends B {
        constructor(t, e) {
            super(t), this._popper = null, this._config = this._getConfig(e), this._menu = this._getMenuElement(), this._inNavbar = this._detectNavbar()
        }
        static get Default() {
            return Pt
        }
        static get DefaultType() {
            return xt
        }
        static get NAME() {
            return ft
        }
        toggle() {
            return this._isShown() ? this.hide() : this.show()
        }
        show() {
            if (d(this._element) || this._isShown(this._menu)) return;
            const t = {
                relatedTarget: this._element
            };
            if (j.trigger(this._element, "show.bs.dropdown", t).defaultPrevented) return;
            const e = Mt.getParentFromElement(this._element);
            this._inNavbar ? K.setDataAttribute(this._menu, "popper", "none") : this._createPopper(e), "ontouchstart" in document.documentElement && !e.closest(".navbar-nav") && [].concat(...document.body.children).forEach(t => j.on(t, "mouseover", g)), this._element.focus(), this._element.setAttribute("aria-expanded", !0), this._menu.classList.add(Tt), this._element.classList.add(Tt), j.trigger(this._element, "shown.bs.dropdown", t)
        }
        hide() {
            !d(this._element) && this._isShown(this._menu) && this._completeHide({
                relatedTarget: this._element
            })
        }
        dispose() {
            this._popper && this._popper.destroy(), super.dispose()
        }
        update() {
            this._inNavbar = this._detectNavbar(), this._popper && this._popper.update()
        }
        _completeHide(t) {
            j.trigger(this._element, "hide.bs.dropdown", t).defaultPrevented || ("ontouchstart" in document.documentElement && [].concat(...document.body.children).forEach(t => j.off(t, "mouseover", g)), this._popper && this._popper.destroy(), this._menu.classList.remove(Tt), this._element.classList.remove(Tt), this._element.setAttribute("aria-expanded", "false"), K.removeDataAttribute(this._menu, "popper"), j.trigger(this._element, "hidden.bs.dropdown", t))
        }
        _getConfig(t) {
            if (t = { ...this.constructor.Default,
                    ...K.getDataAttributes(this._element),
                    ...t
                }, c(ft, t, this.constructor.DefaultType), "object" == typeof t.reference && !a(t.reference) && "function" != typeof t.reference.getBoundingClientRect) throw new TypeError(`${ft.toUpperCase()}: Option "reference" provided type "object" without a required "getBoundingClientRect" method.`);
            return t
        }
        _createPopper(t) {
            if (void 0 === e) throw new TypeError("Bootstrap's dropdowns require Popper (https://popper.js.org)");
            let i = this._element;
            "parent" === this._config.reference ? i = t : a(this._config.reference) ? i = l(this._config.reference) : "object" == typeof this._config.reference && (i = this._config.reference);
            const s = this._getPopperConfig(),
                n = s.modifiers.find(t => "applyStyles" === t.name && !1 === t.enabled);
            this._popper = e.createPopper(i, this._menu, s), n && K.setDataAttribute(this._menu, "popper", "static")
        }
        _isShown(t = this._element) {
            return t.classList.contains(Tt)
        }
        _getMenuElement() {
            return V.next(this._element, kt)[0]
        }
        _getPlacement() {
            const t = this._element.parentNode;
            if (t.classList.contains("dropend")) return Dt;
            if (t.classList.contains("dropstart")) return It;
            const e = "end" === getComputedStyle(this._menu).getPropertyValue("--bs-position").trim();
            return t.classList.contains("dropup") ? e ? St : Lt : e ? Nt : Ot
        }
        _detectNavbar() {
            return null !== this._element.closest(".navbar")
        }
        _getOffset() {
            const {
                offset: t
            } = this._config;
            return "string" == typeof t ? t.split(",").map(t => Number.parseInt(t, 10)) : "function" == typeof t ? e => t(e, this._element) : t
        }
        _getPopperConfig() {
            const t = {
                placement: this._getPlacement(),
                modifiers: [{
                    name: "preventOverflow",
                    options: {
                        boundary: this._config.boundary
                    }
                }, {
                    name: "offset",
                    options: {
                        offset: this._getOffset()
                    }
                }]
            };
            return "static" === this._config.display && (t.modifiers = [{
                name: "applyStyles",
                enabled: !1
            }]), { ...t,
                ..."function" == typeof this._config.popperConfig ? this._config.popperConfig(t) : this._config.popperConfig
            }
        }
        _selectMenuItem({
            key: t,
            target: e
        }) {
            const i = V.find(".dropdown-menu .dropdown-item:not(.disabled):not(:disabled)", this._menu).filter(h);
            i.length && y(i, e, t === yt, !i.includes(e)).focus()
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const e = Mt.getOrCreateInstance(this, t);
                if ("string" == typeof t) {
                    if (void 0 === e[t]) throw new TypeError(`No method named "${t}"`);
                    e[t]()
                }
            })
        }
        static clearMenus(t) {
            if (t && (2 === t.button || "keyup" === t.type && "Tab" !== t.key)) return;
            const e = V.find(Ct);
            for (let i = 0, s = e.length; i < s; i++) {
                const s = Mt.getInstance(e[i]);
                if (!s || !1 === s._config.autoClose) continue;
                if (!s._isShown()) continue;
                const n = {
                    relatedTarget: s._element
                };
                if (t) {
                    const e = t.composedPath(),
                        i = e.includes(s._menu);
                    if (e.includes(s._element) || "inside" === s._config.autoClose && !i || "outside" === s._config.autoClose && i) continue;
                    if (s._menu.contains(t.target) && ("keyup" === t.type && "Tab" === t.key || /input|select|option|textarea|form/i.test(t.target.tagName))) continue;
                    "click" === t.type && (n.clickEvent = t)
                }
                s._completeHide(n)
            }
        }
        static getParentFromElement(t) {
            return o(t) || t.parentNode
        }
        static dataApiKeydownHandler(t) {
            if (/input|textarea/i.test(t.target.tagName) ? t.key === bt || t.key !== mt && (t.key !== yt && t.key !== vt || t.target.closest(kt)) : !Et.test(t.key)) return;
            const e = this.classList.contains(Tt);
            if (!e && t.key === mt) return;
            if (t.preventDefault(), t.stopPropagation(), d(this)) return;
            const i = this.matches(Ct) ? this : V.prev(this, Ct)[0],
                s = Mt.getOrCreateInstance(i);
            if (t.key !== mt) return t.key === vt || t.key === yt ? (e || s.show(), void s._selectMenuItem(t)) : void(e && t.key !== bt || Mt.clearMenus());
            s.hide()
        }
    }
    j.on(document, At, Ct, Mt.dataApiKeydownHandler), j.on(document, At, kt, Mt.dataApiKeydownHandler), j.on(document, wt, Mt.clearMenus), j.on(document, "keyup.bs.dropdown.data-api", Mt.clearMenus), j.on(document, wt, Ct, function(t) {
        t.preventDefault(), Mt.getOrCreateInstance(this).toggle()
    }), m(Mt);
    const jt = ".fixed-top, .fixed-bottom, .is-fixed, .sticky-top",
        Ht = ".sticky-top";
    class $t {
        constructor() {
            this._element = document.body
        }
        getWidth() {
            const t = document.documentElement.clientWidth;
            return Math.abs(window.innerWidth - t)
        }
        hide() {
            const t = this.getWidth();
            this._disableOverFlow(), this._setElementAttributes(this._element, "paddingRight", e => e + t), this._setElementAttributes(jt, "paddingRight", e => e + t), this._setElementAttributes(Ht, "marginRight", e => e - t)
        }
        _disableOverFlow() {
            this._saveInitialAttribute(this._element, "overflow"), this._element.style.overflow = "hidden"
        }
        _setElementAttributes(t, e, i) {
            const s = this.getWidth();
            this._applyManipulationCallback(t, t => {
                if (t !== this._element && window.innerWidth > t.clientWidth + s) return;
                this._saveInitialAttribute(t, e);
                const n = window.getComputedStyle(t)[e];
                t.style[e] = `${i(Number.parseFloat(n))}px`
            })
        }
        reset() {
            this._resetElementAttributes(this._element, "overflow"), this._resetElementAttributes(this._element, "paddingRight"), this._resetElementAttributes(jt, "paddingRight"), this._resetElementAttributes(Ht, "marginRight")
        }
        _saveInitialAttribute(t, e) {
            const i = t.style[e];
            i && K.setDataAttribute(t, e, i)
        }
        _resetElementAttributes(t, e) {
            this._applyManipulationCallback(t, t => {
                const i = K.getDataAttribute(t, e);
                void 0 === i ? t.style.removeProperty(e) : (K.removeDataAttribute(t, e), t.style[e] = i)
            })
        }
        _applyManipulationCallback(t, e) {
            a(t) ? e(t) : V.find(t, this._element).forEach(e)
        }
        isOverflowing() {
            return this.getWidth() > 0
        }
    }
    const Bt = {
            className: "modal-backdrop",
            isVisible: !0,
            isAnimated: !1,
            rootElement: "body",
            clickCallback: null
        },
        zt = {
            className: "string",
            isVisible: "boolean",
            isAnimated: "boolean",
            rootElement: "(element|string)",
            clickCallback: "(function|null)"
        },
        Rt = "show",
        Ft = "mousedown.bs.backdrop";
    class qt {
        constructor(t) {
            this._config = this._getConfig(t), this._isAppended = !1, this._element = null
        }
        show(t) {
            this._config.isVisible ? (this._append(), this._config.isAnimated && this._getElement(), this._getElement().classList.add(Rt), this._emulateAnimation(() => {
                b(t)
            })) : b(t)
        }
        hide(t) {
            this._config.isVisible ? (this._getElement().classList.remove(Rt), this._emulateAnimation(() => {
                this.dispose(), b(t)
            })) : b(t)
        }
        _getElement() {
            if (!this._element) {
                const t = document.createElement("div");
                t.className = this._config.className, this._config.isAnimated && t.classList.add("fade"), this._element = t
            }
            return this._element
        }
        _getConfig(t) {
            return (t = { ...Bt,
                ..."object" == typeof t ? t : {}
            }).rootElement = l(t.rootElement), c("backdrop", t, zt), t
        }
        _append() {
            this._isAppended || (this._config.rootElement.append(this._getElement()), j.on(this._getElement(), Ft, () => {
                b(this._config.clickCallback)
            }), this._isAppended = !0)
        }
        dispose() {
            this._isAppended && (j.off(this._element, Ft), this._element.remove(), this._isAppended = !1)
        }
        _emulateAnimation(t) {
            v(t, this._getElement(), this._config.isAnimated)
        }
    }
    const Wt = {
            trapElement: null,
            autofocus: !0
        },
        Ut = {
            trapElement: "element",
            autofocus: "boolean"
        },
        Kt = ".bs.focustrap",
        Vt = "backward";
    class Xt {
        constructor(t) {
            this._config = this._getConfig(t), this._isActive = !1, this._lastTabNavDirection = null
        }
        activate() {
            const {
                trapElement: t,
                autofocus: e
            } = this._config;
            this._isActive || (e && t.focus(), j.off(document, Kt), j.on(document, "focusin.bs.focustrap", t => this._handleFocusin(t)), j.on(document, "keydown.tab.bs.focustrap", t => this._handleKeydown(t)), this._isActive = !0)
        }
        deactivate() {
            this._isActive && (this._isActive = !1, j.off(document, Kt))
        }
        _handleFocusin(t) {
            const {
                target: e
            } = t, {
                trapElement: i
            } = this._config;
            if (e === document || e === i || i.contains(e)) return;
            const s = V.focusableChildren(i);
            0 === s.length ? i.focus() : this._lastTabNavDirection === Vt ? s[s.length - 1].focus() : s[0].focus()
        }
        _handleKeydown(t) {
            "Tab" === t.key && (this._lastTabNavDirection = t.shiftKey ? Vt : "forward")
        }
        _getConfig(t) {
            return t = { ...Wt,
                ..."object" == typeof t ? t : {}
            }, c("focustrap", t, Ut), t
        }
    }
    const Yt = "modal",
        Qt = "Escape",
        Gt = {
            backdrop: !0,
            keyboard: !0,
            focus: !0
        },
        Zt = {
            backdrop: "(boolean|string)",
            keyboard: "boolean",
            focus: "boolean"
        },
        Jt = "hidden.bs.modal",
        te = "show.bs.modal",
        ee = "resize.bs.modal",
        ie = "click.dismiss.bs.modal",
        se = "keydown.dismiss.bs.modal",
        ne = "mousedown.dismiss.bs.modal",
        oe = "modal-open",
        re = "show",
        ae = "modal-static";
    class le extends B {
        constructor(t, e) {
            super(t), this._config = this._getConfig(e), this._dialog = V.findOne(".modal-dialog", this._element), this._backdrop = this._initializeBackDrop(), this._focustrap = this._initializeFocusTrap(), this._isShown = !1, this._ignoreBackdropClick = !1, this._isTransitioning = !1, this._scrollBar = new $t
        }
        static get Default() {
            return Gt
        }
        static get NAME() {
            return Yt
        }
        toggle(t) {
            return this._isShown ? this.hide() : this.show(t)
        }
        show(t) {
            this._isShown || this._isTransitioning || j.trigger(this._element, te, {
                relatedTarget: t
            }).defaultPrevented || (this._isShown = !0, this._isAnimated() && (this._isTransitioning = !0), this._scrollBar.hide(), document.body.classList.add(oe), this._adjustDialog(), this._setEscapeEvent(), this._setResizeEvent(), j.on(this._dialog, ne, () => {
                j.one(this._element, "mouseup.dismiss.bs.modal", t => {
                    t.target === this._element && (this._ignoreBackdropClick = !0)
                })
            }), this._showBackdrop(() => this._showElement(t)))
        }
        hide() {
            if (!this._isShown || this._isTransitioning) return;
            if (j.trigger(this._element, "hide.bs.modal").defaultPrevented) return;
            this._isShown = !1;
            const t = this._isAnimated();
            t && (this._isTransitioning = !0), this._setEscapeEvent(), this._setResizeEvent(), this._focustrap.deactivate(), this._element.classList.remove(re), j.off(this._element, ie), j.off(this._dialog, ne), this._queueCallback(() => this._hideModal(), this._element, t)
        }
        dispose() {
            [window, this._dialog].forEach(t => j.off(t, ".bs.modal")), this._backdrop.dispose(), this._focustrap.deactivate(), super.dispose()
        }
        handleUpdate() {
            this._adjustDialog()
        }
        _initializeBackDrop() {
            return new qt({
                isVisible: Boolean(this._config.backdrop),
                isAnimated: this._isAnimated()
            })
        }
        _initializeFocusTrap() {
            return new Xt({
                trapElement: this._element
            })
        }
        _getConfig(t) {
            return t = { ...Gt,
                ...K.getDataAttributes(this._element),
                ..."object" == typeof t ? t : {}
            }, c(Yt, t, Zt), t
        }
        _showElement(t) {
            const e = this._isAnimated(),
                i = V.findOne(".modal-body", this._dialog);
            this._element.parentNode && this._element.parentNode.nodeType === Node.ELEMENT_NODE || document.body.append(this._element), this._element.style.display = "block", this._element.removeAttribute("aria-hidden"), this._element.setAttribute("aria-modal", !0), this._element.setAttribute("role", "dialog"), this._element.scrollTop = 0, i && (i.scrollTop = 0), this._element.classList.add(re), this._queueCallback(() => {
                this._config.focus && this._focustrap.activate(), this._isTransitioning = !1, j.trigger(this._element, "shown.bs.modal", {
                    relatedTarget: t
                })
            }, this._dialog, e)
        }
        _setEscapeEvent() {
            this._isShown ? j.on(this._element, se, t => {
                this._config.keyboard && t.key === Qt ? (t.preventDefault(), this.hide()) : this._config.keyboard || t.key !== Qt || this._triggerBackdropTransition()
            }) : j.off(this._element, se)
        }
        _setResizeEvent() {
            this._isShown ? j.on(window, ee, () => this._adjustDialog()) : j.off(window, ee)
        }
        _hideModal() {
            this._element.style.display = "none", this._element.setAttribute("aria-hidden", !0), this._element.removeAttribute("aria-modal"), this._element.removeAttribute("role"), this._isTransitioning = !1, this._backdrop.hide(() => {
                document.body.classList.remove(oe), this._resetAdjustments(), this._scrollBar.reset(), j.trigger(this._element, Jt)
            })
        }
        _showBackdrop(t) {
            j.on(this._element, ie, t => {
                this._ignoreBackdropClick ? this._ignoreBackdropClick = !1 : t.target === t.currentTarget && (!0 === this._config.backdrop ? this.hide() : "static" === this._config.backdrop && this._triggerBackdropTransition())
            }), this._backdrop.show(t)
        }
        _isAnimated() {
            return this._element.classList.contains("fade")
        }
        _triggerBackdropTransition() {
            if (j.trigger(this._element, "hidePrevented.bs.modal").defaultPrevented) return;
            const {
                classList: t,
                scrollHeight: e,
                style: i
            } = this._element, s = e > document.documentElement.clientHeight;
            !s && "hidden" === i.overflowY || t.contains(ae) || (s || (i.overflowY = "hidden"), t.add(ae), this._queueCallback(() => {
                t.remove(ae), s || this._queueCallback(() => {
                    i.overflowY = ""
                }, this._dialog)
            }, this._dialog), this._element.focus())
        }
        _adjustDialog() {
            const t = this._element.scrollHeight > document.documentElement.clientHeight,
                e = this._scrollBar.getWidth(),
                i = e > 0;
            (!i && t && !f() || i && !t && f()) && (this._element.style.paddingLeft = `${e}px`), (i && !t && !f() || !i && t && f()) && (this._element.style.paddingRight = `${e}px`)
        }
        _resetAdjustments() {
            this._element.style.paddingLeft = "", this._element.style.paddingRight = ""
        }
        static jQueryInterface(t, e) {
            return this.each(function() {
                const i = le.getOrCreateInstance(this, t);
                if ("string" == typeof t) {
                    if (void 0 === i[t]) throw new TypeError(`No method named "${t}"`);
                    i[t](e)
                }
            })
        }
    }
    j.on(document, "click.bs.modal.data-api", '[data-bs-toggle="modal"]', function(t) {
        const e = o(this);
        ["A", "AREA"].includes(this.tagName) && t.preventDefault(), j.one(e, te, t => {
            t.defaultPrevented || j.one(e, Jt, () => {
                h(this) && this.focus()
            })
        });
        const i = V.findOne(".modal.show");
        i && le.getInstance(i).hide(), le.getOrCreateInstance(e).toggle(this)
    }), z(le), m(le);
    const ce = "offcanvas",
        he = {
            backdrop: !0,
            keyboard: !0,
            scroll: !1
        },
        de = {
            backdrop: "boolean",
            keyboard: "boolean",
            scroll: "boolean"
        },
        ue = "show",
        ge = ".offcanvas.show",
        _e = "hidden.bs.offcanvas";
    class pe extends B {
        constructor(t, e) {
            super(t), this._config = this._getConfig(e), this._isShown = !1, this._backdrop = this._initializeBackDrop(), this._focustrap = this._initializeFocusTrap(), this._addEventListeners()
        }
        static get NAME() {
            return ce
        }
        static get Default() {
            return he
        }
        toggle(t) {
            return this._isShown ? this.hide() : this.show(t)
        }
        show(t) {
            this._isShown || j.trigger(this._element, "show.bs.offcanvas", {
                relatedTarget: t
            }).defaultPrevented || (this._isShown = !0, this._element.style.visibility = "visible", this._backdrop.show(), this._config.scroll || (new $t).hide(), this._element.removeAttribute("aria-hidden"), this._element.setAttribute("aria-modal", !0), this._element.setAttribute("role", "dialog"), this._element.classList.add(ue), this._queueCallback(() => {
                this._config.scroll || this._focustrap.activate(), j.trigger(this._element, "shown.bs.offcanvas", {
                    relatedTarget: t
                })
            }, this._element, !0))
        }
        hide() {
            this._isShown && (j.trigger(this._element, "hide.bs.offcanvas").defaultPrevented || (this._focustrap.deactivate(), this._element.blur(), this._isShown = !1, this._element.classList.remove(ue), this._backdrop.hide(), this._queueCallback(() => {
                this._element.setAttribute("aria-hidden", !0), this._element.removeAttribute("aria-modal"), this._element.removeAttribute("role"), this._element.style.visibility = "hidden", this._config.scroll || (new $t).reset(), j.trigger(this._element, _e)
            }, this._element, !0)))
        }
        dispose() {
            this._backdrop.dispose(), this._focustrap.deactivate(), super.dispose()
        }
        _getConfig(t) {
            return t = { ...he,
                ...K.getDataAttributes(this._element),
                ..."object" == typeof t ? t : {}
            }, c(ce, t, de), t
        }
        _initializeBackDrop() {
            return new qt({
                className: "offcanvas-backdrop",
                isVisible: this._config.backdrop,
                isAnimated: !0,
                rootElement: this._element.parentNode,
                clickCallback: () => this.hide()
            })
        }
        _initializeFocusTrap() {
            return new Xt({
                trapElement: this._element
            })
        }
        _addEventListeners() {
            j.on(this._element, "keydown.dismiss.bs.offcanvas", t => {
                this._config.keyboard && "Escape" === t.key && this.hide()
            })
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const e = pe.getOrCreateInstance(this, t);
                if ("string" == typeof t) {
                    if (void 0 === e[t] || t.startsWith("_") || "constructor" === t) throw new TypeError(`No method named "${t}"`);
                    e[t](this)
                }
            })
        }
    }
    j.on(document, "click.bs.offcanvas.data-api", '[data-bs-toggle="offcanvas"]', function(t) {
        const e = o(this);
        if (["A", "AREA"].includes(this.tagName) && t.preventDefault(), d(this)) return;
        j.one(e, _e, () => {
            h(this) && this.focus()
        });
        const i = V.findOne(ge);
        i && i !== e && pe.getInstance(i).hide(), pe.getOrCreateInstance(e).toggle(this)
    }), j.on(window, "load.bs.offcanvas.data-api", () => V.find(ge).forEach(t => pe.getOrCreateInstance(t).show())), z(pe), m(pe);
    const fe = new Set(["background", "cite", "href", "itemtype", "longdesc", "poster", "src", "xlink:href"]),
        me = /^(?:(?:https?|mailto|ftp|tel|file|sms):|[^#&/:?]*(?:[#/?]|$))/i,
        be = /^data:(?:image\/(?:bmp|gif|jpeg|jpg|png|tiff|webp)|video\/(?:mpeg|mp4|ogg|webm)|audio\/(?:mp3|oga|ogg|opus));base64,[\d+/a-z]+=*$/i,
        ve = (t, e) => {
            const i = t.nodeName.toLowerCase();
            if (e.includes(i)) return !fe.has(i) || Boolean(me.test(t.nodeValue) || be.test(t.nodeValue));
            const s = e.filter(t => t instanceof RegExp);
            for (let n = 0, o = s.length; n < o; n++)
                if (s[n].test(i)) return !0;
            return !1
        };

    function ye(t, e, i) {
        if (!t.length) return t;
        if (i && "function" == typeof i) return i(t);
        const s = (new window.DOMParser).parseFromString(t, "text/html"),
            n = [].concat(...s.body.querySelectorAll("*"));
        for (let o = 0, r = n.length; o < r; o++) {
            const t = n[o],
                i = t.nodeName.toLowerCase();
            if (!Object.keys(e).includes(i)) {
                t.remove();
                continue
            }
            const s = [].concat(...t.attributes),
                r = [].concat(e["*"] || [], e[i] || []);
            s.forEach(e => {
                ve(e, r) || t.removeAttribute(e.nodeName)
            })
        }
        return s.body.innerHTML
    }
    const Ee = "tooltip",
        we = new Set(["sanitize", "allowList", "sanitizeFn"]),
        Ae = {
            animation: "boolean",
            template: "string",
            title: "(string|element|function)",
            trigger: "string",
            delay: "(number|object)",
            html: "boolean",
            selector: "(string|boolean)",
            placement: "(string|function)",
            offset: "(array|string|function)",
            container: "(string|element|boolean)",
            fallbackPlacements: "array",
            boundary: "(string|element)",
            customClass: "(string|function)",
            sanitize: "boolean",
            sanitizeFn: "(null|function)",
            allowList: "object",
            popperConfig: "(null|object|function)"
        },
        Te = {
            AUTO: "auto",
            TOP: "top",
            RIGHT: f() ? "left" : "right",
            BOTTOM: "bottom",
            LEFT: f() ? "right" : "left"
        },
        Ce = {
            animation: !0,
            template: '<div class="tooltip" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>',
            trigger: "hover focus",
            title: "",
            delay: 0,
            html: !1,
            selector: !1,
            placement: "top",
            offset: [0, 0],
            container: !1,
            fallbackPlacements: ["top", "right", "bottom", "left"],
            boundary: "clippingParents",
            customClass: "",
            sanitize: !0,
            sanitizeFn: null,
            allowList: {
                "*": ["class", "dir", "id", "lang", "role", /^aria-[\w-]*$/i],
                a: ["target", "href", "title", "rel"],
                area: [],
                b: [],
                br: [],
                col: [],
                code: [],
                div: [],
                em: [],
                hr: [],
                h1: [],
                h2: [],
                h3: [],
                h4: [],
                h5: [],
                h6: [],
                i: [],
                img: ["src", "srcset", "alt", "title", "width", "height"],
                li: [],
                ol: [],
                p: [],
                pre: [],
                s: [],
                small: [],
                span: [],
                sub: [],
                sup: [],
                strong: [],
                u: [],
                ul: []
            },
            popperConfig: null
        },
        ke = {
            HIDE: "hide.bs.tooltip",
            HIDDEN: "hidden.bs.tooltip",
            SHOW: "show.bs.tooltip",
            SHOWN: "shown.bs.tooltip",
            INSERTED: "inserted.bs.tooltip",
            CLICK: "click.bs.tooltip",
            FOCUSIN: "focusin.bs.tooltip",
            FOCUSOUT: "focusout.bs.tooltip",
            MOUSEENTER: "mouseenter.bs.tooltip",
            MOUSELEAVE: "mouseleave.bs.tooltip"
        },
        Le = "fade",
        Se = "show",
        Oe = "show",
        Ne = "out",
        De = ".tooltip-inner",
        Ie = ".modal",
        Pe = "hide.bs.modal",
        xe = "hover",
        Me = "focus";
    class je extends B {
        constructor(t, i) {
            if (void 0 === e) throw new TypeError("Bootstrap's tooltips require Popper (https://popper.js.org)");
            super(t), this._isEnabled = !0, this._timeout = 0, this._hoverState = "", this._activeTrigger = {}, this._popper = null, this._config = this._getConfig(i), this.tip = null, this._setListeners()
        }
        static get Default() {
            return Ce
        }
        static get NAME() {
            return Ee
        }
        static get Event() {
            return ke
        }
        static get DefaultType() {
            return Ae
        }
        enable() {
            this._isEnabled = !0
        }
        disable() {
            this._isEnabled = !1
        }
        toggleEnabled() {
            this._isEnabled = !this._isEnabled
        }
        toggle(t) {
            if (this._isEnabled)
                if (t) {
                    const e = this._initializeOnDelegatedTarget(t);
                    e._activeTrigger.click = !e._activeTrigger.click, e._isWithActiveTrigger() ? e._enter(null, e) : e._leave(null, e)
                } else {
                    if (this.getTipElement().classList.contains(Se)) return void this._leave(null, this);
                    this._enter(null, this)
                }
        }
        dispose() {
            clearTimeout(this._timeout), j.off(this._element.closest(Ie), Pe, this._hideModalHandler), this.tip && this.tip.remove(), this._disposePopper(), super.dispose()
        }
        show() {
            if ("none" === this._element.style.display) throw new Error("Please use show on visible elements");
            if (!this.isWithContent() || !this._isEnabled) return;
            const t = j.trigger(this._element, this.constructor.Event.SHOW),
                i = u(this._element),
                s = null === i ? this._element.ownerDocument.documentElement.contains(this._element) : i.contains(this._element);
            if (t.defaultPrevented || !s) return;
            "tooltip" === this.constructor.NAME && this.tip && this.getTitle() !== this.tip.querySelector(De).innerHTML && (this._disposePopper(), this.tip.remove(), this.tip = null);
            const n = this.getTipElement(),
                o = (t => {
                    do {
                        t += Math.floor(1e6 * Math.random())
                    } while (document.getElementById(t));
                    return t
                })(this.constructor.NAME);
            n.setAttribute("id", o), this._element.setAttribute("aria-describedby", o), this._config.animation && n.classList.add(Le);
            const r = "function" == typeof this._config.placement ? this._config.placement.call(this, n, this._element) : this._config.placement,
                a = this._getAttachment(r);
            this._addAttachmentClass(a);
            const {
                container: l
            } = this._config;
            $.set(n, this.constructor.DATA_KEY, this), this._element.ownerDocument.documentElement.contains(this.tip) || (l.append(n), j.trigger(this._element, this.constructor.Event.INSERTED)), this._popper ? this._popper.update() : this._popper = e.createPopper(this._element, n, this._getPopperConfig(a)), n.classList.add(Se);
            const c = this._resolvePossibleFunction(this._config.customClass);
            c && n.classList.add(...c.split(" ")), "ontouchstart" in document.documentElement && [].concat(...document.body.children).forEach(t => {
                j.on(t, "mouseover", g)
            });
            const h = this.tip.classList.contains(Le);
            this._queueCallback(() => {
                const t = this._hoverState;
                this._hoverState = null, j.trigger(this._element, this.constructor.Event.SHOWN), t === Ne && this._leave(null, this)
            }, this.tip, h)
        }
        hide() {
            if (!this._popper) return;
            const t = this.getTipElement();
            if (j.trigger(this._element, this.constructor.Event.HIDE).defaultPrevented) return;
            t.classList.remove(Se), "ontouchstart" in document.documentElement && [].concat(...document.body.children).forEach(t => j.off(t, "mouseover", g)), this._activeTrigger.click = !1, this._activeTrigger.focus = !1, this._activeTrigger.hover = !1;
            const e = this.tip.classList.contains(Le);
            this._queueCallback(() => {
                this._isWithActiveTrigger() || (this._hoverState !== Oe && t.remove(), this._cleanTipClass(), this._element.removeAttribute("aria-describedby"), j.trigger(this._element, this.constructor.Event.HIDDEN), this._disposePopper())
            }, this.tip, e), this._hoverState = ""
        }
        update() {
            null !== this._popper && this._popper.update()
        }
        isWithContent() {
            return Boolean(this.getTitle())
        }
        getTipElement() {
            if (this.tip) return this.tip;
            const t = document.createElement("div");
            t.innerHTML = this._config.template;
            const e = t.children[0];
            return this.setContent(e), e.classList.remove(Le, Se), this.tip = e, this.tip
        }
        setContent(t) {
            this._sanitizeAndSetContent(t, this.getTitle(), De)
        }
        _sanitizeAndSetContent(t, e, i) {
            const s = V.findOne(i, t);
            e || !s ? this.setElementContent(s, e) : s.remove()
        }
        setElementContent(t, e) {
            if (null !== t) return a(e) ? (e = l(e), void(this._config.html ? e.parentNode !== t && (t.innerHTML = "", t.append(e)) : t.textContent = e.textContent)) : void(this._config.html ? (this._config.sanitize && (e = ye(e, this._config.allowList, this._config.sanitizeFn)), t.innerHTML = e) : t.textContent = e)
        }
        getTitle() {
            const t = this._element.getAttribute("data-bs-original-title") || this._config.title;
            return this._resolvePossibleFunction(t)
        }
        updateAttachment(t) {
            return "right" === t ? "end" : "left" === t ? "start" : t
        }
        _initializeOnDelegatedTarget(t, e) {
            return e || this.constructor.getOrCreateInstance(t.delegateTarget, this._getDelegateConfig())
        }
        _getOffset() {
            const {
                offset: t
            } = this._config;
            return "string" == typeof t ? t.split(",").map(t => Number.parseInt(t, 10)) : "function" == typeof t ? e => t(e, this._element) : t
        }
        _resolvePossibleFunction(t) {
            return "function" == typeof t ? t.call(this._element) : t
        }
        _getPopperConfig(t) {
            const e = {
                placement: t,
                modifiers: [{
                    name: "flip",
                    options: {
                        fallbackPlacements: this._config.fallbackPlacements
                    }
                }, {
                    name: "offset",
                    options: {
                        offset: this._getOffset()
                    }
                }, {
                    name: "preventOverflow",
                    options: {
                        boundary: this._config.boundary
                    }
                }, {
                    name: "arrow",
                    options: {
                        element: `.${this.constructor.NAME}-arrow`
                    }
                }, {
                    name: "onChange",
                    enabled: !0,
                    phase: "afterWrite",
                    fn: t => this._handlePopperPlacementChange(t)
                }],
                onFirstUpdate: t => {
                    t.options.placement !== t.placement && this._handlePopperPlacementChange(t)
                }
            };
            return { ...e,
                ..."function" == typeof this._config.popperConfig ? this._config.popperConfig(e) : this._config.popperConfig
            }
        }
        _addAttachmentClass(t) {
            this.getTipElement().classList.add(`${this._getBasicClassPrefix()}-${this.updateAttachment(t)}`)
        }
        _getAttachment(t) {
            return Te[t.toUpperCase()]
        }
        _setListeners() {
            this._config.trigger.split(" ").forEach(t => {
                if ("click" === t) j.on(this._element, this.constructor.Event.CLICK, this._config.selector, t => this.toggle(t));
                else if ("manual" !== t) {
                    const e = t === xe ? this.constructor.Event.MOUSELEAVE : this.constructor.Event.FOCUSOUT;
                    j.on(this._element, t === xe ? this.constructor.Event.MOUSEENTER : this.constructor.Event.FOCUSIN, this._config.selector, t => this._enter(t)), j.on(this._element, e, this._config.selector, t => this._leave(t))
                }
            }), this._hideModalHandler = () => {
                this._element && this.hide()
            }, j.on(this._element.closest(Ie), Pe, this._hideModalHandler), this._config.selector ? this._config = { ...this._config,
                trigger: "manual",
                selector: ""
            } : this._fixTitle()
        }
        _fixTitle() {
            const t = this._element.getAttribute("title"),
                e = typeof this._element.getAttribute("data-bs-original-title");
            (t || "string" !== e) && (this._element.setAttribute("data-bs-original-title", t || ""), !t || this._element.getAttribute("aria-label") || this._element.textContent || this._element.setAttribute("aria-label", t), this._element.setAttribute("title", ""))
        }
        _enter(t, e) {
            e = this._initializeOnDelegatedTarget(t, e), t && (e._activeTrigger["focusin" === t.type ? Me : xe] = !0), e.getTipElement().classList.contains(Se) || e._hoverState === Oe ? e._hoverState = Oe : (clearTimeout(e._timeout), e._hoverState = Oe, e._config.delay && e._config.delay.show ? e._timeout = setTimeout(() => {
                e._hoverState === Oe && e.show()
            }, e._config.delay.show) : e.show())
        }
        _leave(t, e) {
            e = this._initializeOnDelegatedTarget(t, e), t && (e._activeTrigger["focusout" === t.type ? Me : xe] = e._element.contains(t.relatedTarget)), e._isWithActiveTrigger() || (clearTimeout(e._timeout), e._hoverState = Ne, e._config.delay && e._config.delay.hide ? e._timeout = setTimeout(() => {
                e._hoverState === Ne && e.hide()
            }, e._config.delay.hide) : e.hide())
        }
        _isWithActiveTrigger() {
            for (const t in this._activeTrigger)
                if (this._activeTrigger[t]) return !0;
            return !1
        }
        _getConfig(t) {
            const e = K.getDataAttributes(this._element);
            return Object.keys(e).forEach(t => {
                we.has(t) && delete e[t]
            }), (t = { ...this.constructor.Default,
                ...e,
                ..."object" == typeof t && t ? t : {}
            }).container = !1 === t.container ? document.body : l(t.container), "number" == typeof t.delay && (t.delay = {
                show: t.delay,
                hide: t.delay
            }), "number" == typeof t.title && (t.title = t.title.toString()), "number" == typeof t.content && (t.content = t.content.toString()), c(Ee, t, this.constructor.DefaultType), t.sanitize && (t.template = ye(t.template, t.allowList, t.sanitizeFn)), t
        }
        _getDelegateConfig() {
            const t = {};
            for (const e in this._config) this.constructor.Default[e] !== this._config[e] && (t[e] = this._config[e]);
            return t
        }
        _cleanTipClass() {
            const t = this.getTipElement(),
                e = new RegExp(`(^|\\s)${this._getBasicClassPrefix()}\\S+`, "g"),
                i = t.getAttribute("class").match(e);
            null !== i && i.length > 0 && i.map(t => t.trim()).forEach(e => t.classList.remove(e))
        }
        _getBasicClassPrefix() {
            return "bs-tooltip"
        }
        _handlePopperPlacementChange(t) {
            const {
                state: e
            } = t;
            e && (this.tip = e.elements.popper, this._cleanTipClass(), this._addAttachmentClass(this._getAttachment(e.placement)))
        }
        _disposePopper() {
            this._popper && (this._popper.destroy(), this._popper = null)
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const e = je.getOrCreateInstance(this, t);
                if ("string" == typeof t) {
                    if (void 0 === e[t]) throw new TypeError(`No method named "${t}"`);
                    e[t]()
                }
            })
        }
    }
    m(je);
    const He = { ...je.Default,
            placement: "right",
            offset: [0, 8],
            trigger: "click",
            content: "",
            template: '<div class="popover" role="tooltip"><div class="popover-arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div></div>'
        },
        $e = { ...je.DefaultType,
            content: "(string|element|function)"
        },
        Be = {
            HIDE: "hide.bs.popover",
            HIDDEN: "hidden.bs.popover",
            SHOW: "show.bs.popover",
            SHOWN: "shown.bs.popover",
            INSERTED: "inserted.bs.popover",
            CLICK: "click.bs.popover",
            FOCUSIN: "focusin.bs.popover",
            FOCUSOUT: "focusout.bs.popover",
            MOUSEENTER: "mouseenter.bs.popover",
            MOUSELEAVE: "mouseleave.bs.popover"
        };
    class ze extends je {
        static get Default() {
            return He
        }
        static get NAME() {
            return "popover"
        }
        static get Event() {
            return Be
        }
        static get DefaultType() {
            return $e
        }
        isWithContent() {
            return this.getTitle() || this._getContent()
        }
        setContent(t) {
            this._sanitizeAndSetContent(t, this.getTitle(), ".popover-header"), this._sanitizeAndSetContent(t, this._getContent(), ".popover-body")
        }
        _getContent() {
            return this._resolvePossibleFunction(this._config.content)
        }
        _getBasicClassPrefix() {
            return "bs-popover"
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const e = ze.getOrCreateInstance(this, t);
                if ("string" == typeof t) {
                    if (void 0 === e[t]) throw new TypeError(`No method named "${t}"`);
                    e[t]()
                }
            })
        }
    }
    m(ze);
    const Re = "scrollspy",
        Fe = {
            offset: 10,
            method: "auto",
            target: ""
        },
        qe = {
            offset: "number",
            method: "string",
            target: "(string|element)"
        },
        We = "active",
        Ue = ".nav-link, .list-group-item, .dropdown-item",
        Ke = "position";
    class Ve extends B {
        constructor(t, e) {
            super(t), this._scrollElement = "BODY" === this._element.tagName ? window : this._element, this._config = this._getConfig(e), this._offsets = [], this._targets = [], this._activeTarget = null, this._scrollHeight = 0, j.on(this._scrollElement, "scroll.bs.scrollspy", () => this._process()), this.refresh(), this._process()
        }
        static get Default() {
            return Fe
        }
        static get NAME() {
            return Re
        }
        refresh() {
            const t = "auto" === this._config.method ? this._scrollElement === this._scrollElement.window ? "offset" : Ke : this._config.method,
                e = t === Ke ? this._getScrollTop() : 0;
            this._offsets = [], this._targets = [], this._scrollHeight = this._getScrollHeight(), V.find(Ue, this._config.target).map(i => {
                const s = n(i),
                    o = s ? V.findOne(s) : null;
                if (o) {
                    const i = o.getBoundingClientRect();
                    if (i.width || i.height) return [K[t](o).top + e, s]
                }
                return null
            }).filter(t => t).sort((t, e) => t[0] - e[0]).forEach(t => {
                this._offsets.push(t[0]), this._targets.push(t[1])
            })
        }
        dispose() {
            j.off(this._scrollElement, ".bs.scrollspy"), super.dispose()
        }
        _getConfig(t) {
            return (t = { ...Fe,
                ...K.getDataAttributes(this._element),
                ..."object" == typeof t && t ? t : {}
            }).target = l(t.target) || document.documentElement, c(Re, t, qe), t
        }
        _getScrollTop() {
            return this._scrollElement === window ? this._scrollElement.pageYOffset : this._scrollElement.scrollTop
        }
        _getScrollHeight() {
            return this._scrollElement.scrollHeight || Math.max(document.body.scrollHeight, document.documentElement.scrollHeight)
        }
        _getOffsetHeight() {
            return this._scrollElement === window ? window.innerHeight : this._scrollElement.getBoundingClientRect().height
        }
        _process() {
            const t = this._getScrollTop() + this._config.offset,
                e = this._getScrollHeight(),
                i = this._config.offset + e - this._getOffsetHeight();
            if (this._scrollHeight !== e && this.refresh(), t >= i) {
                const t = this._targets[this._targets.length - 1];
                this._activeTarget !== t && this._activate(t)
            } else {
                if (this._activeTarget && t < this._offsets[0] && this._offsets[0] > 0) return this._activeTarget = null, void this._clear();
                for (let e = this._offsets.length; e--;) this._activeTarget !== this._targets[e] && t >= this._offsets[e] && (void 0 === this._offsets[e + 1] || t < this._offsets[e + 1]) && this._activate(this._targets[e])
            }
        }
        _activate(t) {
            this._activeTarget = t, this._clear();
            const e = Ue.split(",").map(e => `${e}[data-bs-target="${t}"],${e}[href="${t}"]`),
                i = V.findOne(e.join(","), this._config.target);
            i.classList.add(We), i.classList.contains("dropdown-item") ? V.findOne(".dropdown-toggle", i.closest(".dropdown")).classList.add(We) : V.parents(i, ".nav, .list-group").forEach(t => {
                V.prev(t, ".nav-link, .list-group-item").forEach(t => t.classList.add(We)), V.prev(t, ".nav-item").forEach(t => {
                    V.children(t, ".nav-link").forEach(t => t.classList.add(We))
                })
            }), j.trigger(this._scrollElement, "activate.bs.scrollspy", {
                relatedTarget: t
            })
        }
        _clear() {
            V.find(Ue, this._config.target).filter(t => t.classList.contains(We)).forEach(t => t.classList.remove(We))
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const e = Ve.getOrCreateInstance(this, t);
                if ("string" == typeof t) {
                    if (void 0 === e[t]) throw new TypeError(`No method named "${t}"`);
                    e[t]()
                }
            })
        }
    }
    j.on(window, "load.bs.scrollspy.data-api", () => {
        V.find('[data-bs-spy="scroll"]').forEach(t => new Ve(t))
    }), m(Ve);
    const Xe = "active",
        Ye = "fade",
        Qe = "show",
        Ge = ".active",
        Ze = ":scope > li > .active";
    class Je extends B {
        static get NAME() {
            return "tab"
        }
        show() {
            if (this._element.parentNode && this._element.parentNode.nodeType === Node.ELEMENT_NODE && this._element.classList.contains(Xe)) return;
            let t;
            const e = o(this._element),
                i = this._element.closest(".nav, .list-group");
            i && (t = V.find("UL" === i.nodeName || "OL" === i.nodeName ? Ze : Ge, i), t = t[t.length - 1]);
            const s = t ? j.trigger(t, "hide.bs.tab", {
                relatedTarget: this._element
            }) : null;
            if (j.trigger(this._element, "show.bs.tab", {
                    relatedTarget: t
                }).defaultPrevented || null !== s && s.defaultPrevented) return;
            this._activate(this._element, i);
            const n = () => {
                j.trigger(t, "hidden.bs.tab", {
                    relatedTarget: this._element
                }), j.trigger(this._element, "shown.bs.tab", {
                    relatedTarget: t
                })
            };
            e ? this._activate(e, e.parentNode, n) : n()
        }
        _activate(t, e, i) {
            const s = (!e || "UL" !== e.nodeName && "OL" !== e.nodeName ? V.children(e, Ge) : V.find(Ze, e))[0],
                n = i && s && s.classList.contains(Ye),
                o = () => this._transitionComplete(t, s, i);
            s && n ? (s.classList.remove(Qe), this._queueCallback(o, t, !0)) : o()
        }
        _transitionComplete(t, e, i) {
            if (e) {
                e.classList.remove(Xe);
                const t = V.findOne(":scope > .dropdown-menu .active", e.parentNode);
                t && t.classList.remove(Xe), "tab" === e.getAttribute("role") && e.setAttribute("aria-selected", !1)
            }
            t.classList.add(Xe), "tab" === t.getAttribute("role") && t.setAttribute("aria-selected", !0), t.classList.contains(Ye) && t.classList.add(Qe);
            let s = t.parentNode;
            if (s && "LI" === s.nodeName && (s = s.parentNode), s && s.classList.contains("dropdown-menu")) {
                const e = t.closest(".dropdown");
                e && V.find(".dropdown-toggle", e).forEach(t => t.classList.add(Xe)), t.setAttribute("aria-expanded", !0)
            }
            i && i()
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const e = Je.getOrCreateInstance(this);
                if ("string" == typeof t) {
                    if (void 0 === e[t]) throw new TypeError(`No method named "${t}"`);
                    e[t]()
                }
            })
        }
    }
    j.on(document, "click.bs.tab.data-api", '[data-bs-toggle="tab"], [data-bs-toggle="pill"], [data-bs-toggle="list"]', function(t) {
        ["A", "AREA"].includes(this.tagName) && t.preventDefault(), d(this) || Je.getOrCreateInstance(this).show()
    }), m(Je);
    const ti = "toast",
        ei = "hide",
        ii = "show",
        si = "showing",
        ni = {
            animation: "boolean",
            autohide: "boolean",
            delay: "number"
        },
        oi = {
            animation: !0,
            autohide: !0,
            delay: 5e3
        };
    class ri extends B {
        constructor(t, e) {
            super(t), this._config = this._getConfig(e), this._timeout = null, this._hasMouseInteraction = !1, this._hasKeyboardInteraction = !1, this._setListeners()
        }
        static get DefaultType() {
            return ni
        }
        static get Default() {
            return oi
        }
        static get NAME() {
            return ti
        }
        show() {
            j.trigger(this._element, "show.bs.toast").defaultPrevented || (this._clearTimeout(), this._config.animation && this._element.classList.add("fade"), this._element.classList.remove(ei), this._element.classList.add(ii), this._element.classList.add(si), this._queueCallback(() => {
                this._element.classList.remove(si), j.trigger(this._element, "shown.bs.toast"), this._maybeScheduleHide()
            }, this._element, this._config.animation))
        }
        hide() {
            this._element.classList.contains(ii) && (j.trigger(this._element, "hide.bs.toast").defaultPrevented || (this._element.classList.add(si), this._queueCallback(() => {
                this._element.classList.add(ei), this._element.classList.remove(si), this._element.classList.remove(ii), j.trigger(this._element, "hidden.bs.toast")
            }, this._element, this._config.animation)))
        }
        dispose() {
            this._clearTimeout(), this._element.classList.contains(ii) && this._element.classList.remove(ii), super.dispose()
        }
        _getConfig(t) {
            return t = { ...oi,
                ...K.getDataAttributes(this._element),
                ..."object" == typeof t && t ? t : {}
            }, c(ti, t, this.constructor.DefaultType), t
        }
        _maybeScheduleHide() {
            this._config.autohide && (this._hasMouseInteraction || this._hasKeyboardInteraction || (this._timeout = setTimeout(() => {
                this.hide()
            }, this._config.delay)))
        }
        _onInteraction(t, e) {
            switch (t.type) {
                case "mouseover":
                case "mouseout":
                    this._hasMouseInteraction = e;
                    break;
                case "focusin":
                case "focusout":
                    this._hasKeyboardInteraction = e
            }
            if (e) return void this._clearTimeout();
            const i = t.relatedTarget;
            this._element === i || this._element.contains(i) || this._maybeScheduleHide()
        }
        _setListeners() {
            j.on(this._element, "mouseover.bs.toast", t => this._onInteraction(t, !0)), j.on(this._element, "mouseout.bs.toast", t => this._onInteraction(t, !1)), j.on(this._element, "focusin.bs.toast", t => this._onInteraction(t, !0)), j.on(this._element, "focusout.bs.toast", t => this._onInteraction(t, !1))
        }
        _clearTimeout() {
            clearTimeout(this._timeout), this._timeout = null
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const e = ri.getOrCreateInstance(this, t);
                if ("string" == typeof t) {
                    if (void 0 === e[t]) throw new TypeError(`No method named "${t}"`);
                    e[t](this)
                }
            })
        }
    }
    return z(ri), m(ri), {
        Alert: R,
        Button: q,
        Carousel: ot,
        Collapse: pt,
        Dropdown: Mt,
        Modal: le,
        Offcanvas: pe,
        Popover: ze,
        ScrollSpy: Ve,
        Tab: Je,
        Toast: ri,
        Tooltip: je
    }
});